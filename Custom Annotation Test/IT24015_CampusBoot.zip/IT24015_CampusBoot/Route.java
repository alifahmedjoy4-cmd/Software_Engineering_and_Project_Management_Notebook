import java.lang.annotation.*;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Route {
    // Spec asks for path(); starter code uses the shorthand @Route("/hello"),
    // which Java only allows through an element named value(). Both are supported.
    String path() default "";
    String value() default "";
}
